var tempHumidityChart, ecChart, soilChart, healthChart;
var currentData;

function formatTime(isoString) {
    var d = new Date(isoString);
    var hh = String(d.getHours()).padStart(2, '0');
    var mm = String(d.getMinutes()).padStart(2, '0');
    var ss = String(d.getSeconds()).padStart(2, '0');
    return hh + ':' + mm + ':' + ss;
}

function formatDate(isoString) {
    var d = new Date(isoString);
    var M = String(d.getMonth() + 1).padStart(2, '0');
    var D = String(d.getDate()).padStart(2, '0');
    var hh = String(d.getHours()).padStart(2, '0');
    var mm = String(d.getMinutes()).padStart(2, '0');
    return M + '/' + D + ' ' + hh + ':' + mm;
}

// 初始化图表
function initCharts() {
    var chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
                labels: { font: { size: 11 }, boxWidth: 12, padding: 12 }
            },
            tooltip: { mode: 'index', intersect: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: '#f0f0f0' },
                ticks: { font: { size: 11 } }
            },
            x: {
                grid: { display: false },
                ticks: { font: { size: 10 }, maxRotation: 45, minRotation: 45 }
            }
        }
    };

    var ctx1 = document.getElementById('tempHumidityChart').getContext('2d');
    tempHumidityChart = new Chart(ctx1, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: '温度 (C)',
                    data: [],
                    borderColor: '#ff6b6b',
                    backgroundColor: 'rgba(255,107,107,0.08)',
                    tension: 0.3,
                    borderWidth: 1.5,
                    pointRadius: 2,
                    pointHoverRadius: 4
                },
                {
                    label: '湿度 (%)',
                    data: [],
                    borderColor: '#4dabf7',
                    backgroundColor: 'rgba(77,171,247,0.08)',
                    tension: 0.3,
                    borderWidth: 1.5,
                    pointRadius: 2,
                    pointHoverRadius: 4
                }
            ]
        },
        options: chartOptions
    });

    var ctx2 = document.getElementById('ecChart').getContext('2d');
    ecChart = new Chart(ctx2, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'EC (uS/cm)',
                data: [],
                borderColor: '#9775fa',
                backgroundColor: 'rgba(151,117,250,0.08)',
                tension: 0.3,
                borderWidth: 1.5,
                pointRadius: 2,
                pointHoverRadius: 4
            }]
        },
        options: chartOptions
    });

    var ctx3 = document.getElementById('soilChart').getContext('2d');
    soilChart = new Chart(ctx3, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: '土壤湿度',
                data: [],
                borderColor: '#20c997',
                backgroundColor: 'rgba(32,201,151,0.08)',
                tension: 0.3,
                borderWidth: 1.5,
                pointRadius: 2,
                pointHoverRadius: 4
            }]
        },
        options: chartOptions
    });

    var healthOptions = Object.assign({}, chartOptions);
    healthOptions.scales = Object.assign({}, chartOptions.scales);
    healthOptions.scales.y = {
        min: 0,
        max: 100,
        grid: { color: '#f0f0f0' },
        ticks: { font: { size: 11 }, stepSize: 20 }
    };
    healthOptions.scales.x = chartOptions.scales.x;

    var ctx4 = document.getElementById('healthChart').getContext('2d');
    healthChart = new Chart(ctx4, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: '健康度 (%)',
                data: [],
                borderColor: '#fab005',
                backgroundColor: 'rgba(250,176,5,0.08)',
                tension: 0.3,
                borderWidth: 1.5,
                pointRadius: 2,
                pointHoverRadius: 4
            }]
        },
        options: healthOptions
    });
}

function updateStageProgress(stage) {
    var bar = document.getElementById('stageProgress');
    var progress = ((stage + 1) / 4) * 100;
    bar.style.width = progress + '%';
}

function loadLatestData() {
    fetch('/api/latest')
        .then(function(res) { return res.json(); })
        .then(function(data) {
            currentData = data;

            document.getElementById('temperature').textContent = data.temperature ? data.temperature.toFixed(1) + '°C' : '--°C';
            document.getElementById('humidity').textContent = data.humidity ? data.humidity.toFixed(1) + '%' : '--%';
            document.getElementById('light').textContent = data.light || '--';
            document.getElementById('soil').textContent = data.soil || '--';
            document.getElementById('ec').textContent = data.ec ? data.ec + ' uS/cm' : '-- uS/cm';
            document.getElementById('health').textContent = data.health != null ? data.health + '%' : '--%';

            var stageName = data.stage_name || '--';
            document.getElementById('growthStage').textContent = stageName;

            if (data.stage !== undefined) {
                updateStageProgress(data.stage);
            }

            var trendEl = document.getElementById('trend');
            if (data.trend > 0.5) {
                trendEl.textContent = '上升';
                trendEl.style.color = '#52c41a';
            } else if (data.trend < -0.5) {
                trendEl.textContent = '下降';
                trendEl.style.color = '#ff4d4f';
            } else {
                trendEl.textContent = '平稳';
                trendEl.style.color = '#888';
            }

            if (data.timestamp) {
                document.getElementById('lastUpdate').textContent = '最后更新: ' + formatTime(data.timestamp);
            }

            var statusEl = document.getElementById('connectionStatus');
            statusEl.textContent = '在线';
            statusEl.style.color = '#52c41a';
        })
        .catch(function(err) {
            console.error('加载数据失败:', err);
            var statusEl = document.getElementById('connectionStatus');
            statusEl.textContent = '离线';
            statusEl.style.color = '#ff4d4f';
        });
}

function load24hData() {
    fetch('/api/last24h')
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (!data || data.length === 0) return;

            var labels = data.map(function(d) { return formatDate(d.timestamp); });

            tempHumidityChart.data.labels = labels;
            tempHumidityChart.data.datasets[0].data = data.map(function(d) { return d.temperature; });
            tempHumidityChart.data.datasets[1].data = data.map(function(d) { return d.humidity; });
            tempHumidityChart.update();

            ecChart.data.labels = labels;
            ecChart.data.datasets[0].data = data.map(function(d) { return d.ec; });
            ecChart.update();

            soilChart.data.labels = labels;
            soilChart.data.datasets[0].data = data.map(function(d) { return d.soil; });
            soilChart.update();

            healthChart.data.labels = labels;
            healthChart.data.datasets[0].data = data.map(function(d) { return d.health; });
            healthChart.update();
        })
        .catch(function(err) { console.error('加载24h数据失败:', err); });
}

function loadImages() {
    fetch('/api/images?limit=12')
        .then(function(res) { return res.json(); })
        .then(function(data) {
            var grid = document.getElementById('photoGrid');
            if (!data || data.length === 0) {
                grid.innerHTML = '<p style="color:#888;font-size:13px;">暂无照片</p>';
                return;
            }
            grid.innerHTML = data.map(function(img) {
                var badgeClass = img.health > 70 ? 'high' : (img.health > 40 ? 'medium' : 'low');
                return '<div class="photo-item">' +
                    '<img src="/uploads/' + img.filename + '" alt="plant photo" loading="lazy">' +
                    '<div class="photo-info">' +
                        '<div>' + formatDate(img.timestamp) + '</div>' +
                        '<span class="health-badge ' + badgeClass + '">' + (img.health || '--') + '%</span>' +
                    '</div>' +
                '</div>';
            }).join('');
        })
        .catch(function(err) { console.error('加载图片失败:', err); });
}

function loadConfig() {
    fetch('/api/config')
        .then(function(res) { return res.json(); })
        .then(function(config) {
            if (!config) return;
            document.getElementById('plantAgeDays').value = config.plant_age_days || 30;
            document.getElementById('soilTargetMin').value = config.soil_target_min || 1800;
            document.getElementById('soilTargetMax').value = config.soil_target_max || 2500;
            document.getElementById('ecGrowthMin').value = config.ec_growth_min || 150;
            document.getElementById('ecGrowthMax').value = config.ec_growth_max || 300;
            document.getElementById('wateringCooldown').value = config.watering_cooldown || 5;
            document.getElementById('fertilizerCooldown').value = config.fertilizer_cooldown || 60;
        })
        .catch(function(err) { console.error('加载配置失败:', err); });
}

function saveConfig() {
    var config = {
        plant_age_days: parseInt(document.getElementById('plantAgeDays').value) || 30,
        soil_target_min: parseInt(document.getElementById('soilTargetMin').value) || 1800,
        soil_target_max: parseInt(document.getElementById('soilTargetMax').value) || 2500,
        ec_growth_min: parseInt(document.getElementById('ecGrowthMin').value) || 150,
        ec_growth_max: parseInt(document.getElementById('ecGrowthMax').value) || 300,
        watering_cooldown: parseInt(document.getElementById('wateringCooldown').value) || 5,
        fertilizer_cooldown: parseInt(document.getElementById('fertilizerCooldown').value) || 60
    };

    fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
    })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (data.success) {
            alert('配置已保存');
        } else {
            alert('保存失败: ' + (data.error || '未知错误'));
        }
    })
    .catch(function(err) {
        console.error('保存配置失败:', err);
        alert('保存失败');
    });
}

function loadStats() {
    fetch('/api/stats')
        .then(function(res) { return res.json(); })
        .then(function(stats) {
            var grid = document.getElementById('statsGrid');
            var html = '';

            if (stats.today) {
                html += '<div class="stat-item"><div class="stat-label">今日记录数</div><div class="stat-value">' + (stats.today.count || 0) + '</div></div>';
                html += '<div class="stat-item"><div class="stat-label">今日平均健康</div><div class="stat-value">' + (stats.today.avg_health ? stats.today.avg_health.toFixed(1) + '%' : '--') + '</div></div>';
                html += '<div class="stat-item"><div class="stat-label">今日最高健康</div><div class="stat-value">' + (stats.today.max_health ? stats.today.max_health + '%' : '--') + '</div></div>';
                html += '<div class="stat-item"><div class="stat-label">今日最低健康</div><div class="stat-value">' + (stats.today.min_health ? stats.today.min_health + '%' : '--') + '</div></div>';
            }
            if (stats.weekly) {
                html += '<div class="stat-item"><div class="stat-label">7天平均温度</div><div class="stat-value">' + (stats.weekly.avg_temp ? stats.weekly.avg_temp.toFixed(1) + '°C' : '--') + '</div></div>';
                html += '<div class="stat-item"><div class="stat-label">7天平均湿度</div><div class="stat-value">' + (stats.weekly.avg_humidity ? stats.weekly.avg_humidity.toFixed(1) + '%' : '--') + '</div></div>';
                html += '<div class="stat-item"><div class="stat-label">7天平均EC</div><div class="stat-value">' + (stats.weekly.avg_ec ? stats.weekly.avg_ec.toFixed(0) : '--') + '</div></div>';
            }
            grid.innerHTML = html || '<p style="color:#888;font-size:13px;">暂无统计数据</p>';
        })
        .catch(function(err) { console.error('加载统计失败:', err); });
}

function refreshAll() {
    loadLatestData();
    load24hData();
    loadImages();
    loadConfig();
    loadStats();
}

document.addEventListener('DOMContentLoaded', function() {
    initCharts();
    refreshAll();
    setInterval(refreshAll, 30000);
});
