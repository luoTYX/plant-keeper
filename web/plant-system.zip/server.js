const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const moment = require('moment');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

// 确保上传目录存在
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

// 配置文件上传
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/')
    },
    filename: function (req, file, cb) {
        const date = moment().format('YYYYMMDD_HHmmss');
        cb(null, `plant_${date}.jpg`)
    }
});
const upload = multer({ storage: storage, limits: { fileSize: 5 * 1024 * 1024 } });

// 初始化数据库
const db = new sqlite3.Database('./plant_data.db');
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS sensor_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        temperature REAL,
        humidity REAL,
        light INTEGER,
        soil INTEGER,
        ec INTEGER,
        health INTEGER,
        stage INTEGER,
        stage_name TEXT,
        trend REAL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT,
        health INTEGER,
        stage INTEGER,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS device_config (
        id INTEGER PRIMARY KEY CHECK (id=1),
        plant_age_days INTEGER DEFAULT 30,
        soil_target_min INTEGER DEFAULT 1800,
        soil_target_max INTEGER DEFAULT 2500,
        ec_growth_min INTEGER DEFAULT 150,
        ec_growth_max INTEGER DEFAULT 300,
        watering_cooldown INTEGER DEFAULT 5,
        fertilizer_cooldown INTEGER DEFAULT 60,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.get("SELECT * FROM device_config WHERE id=1", (err, row) => {
        if (!row) {
            db.run(`INSERT INTO device_config (id, plant_age_days, soil_target_min, soil_target_max,
                    ec_growth_min, ec_growth_max, watering_cooldown, fertilizer_cooldown)
                    VALUES (1, 30, 1800, 2500, 150, 300, 5, 60)`);
        }
    });
});

// =================== API 路由 ===================

// 上传传感器数据和图片
app.post('/api/upload', upload.single('image'), (req, res) => {
    try {
        const sensorData = JSON.parse(req.body.data);
        const imageFile = req.file;

        db.run(`INSERT INTO sensor_data 
                (temperature, humidity, light, soil, ec, health, stage, stage_name, trend) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [sensorData.temp, sensorData.humidity, sensorData.light,
             sensorData.soil, sensorData.ec, sensorData.health,
             sensorData.stage, sensorData.stage_name, sensorData.trend || 0],
            function(err) {
                if (err) console.error('数据库错误:', err);
            }
        );

        if (imageFile) {
            db.run(`INSERT INTO images (filename, health, stage) VALUES (?, ?, ?)`,
                [imageFile.filename, sensorData.health, sensorData.stage]);
        }

        res.json({ success: true, message: '数据上传成功' });
    } catch (error) {
        console.error('上传错误:', error);
        res.status(500).json({ error: '服务器错误' });
    }
});

// 获取最新传感器数据
app.get('/api/latest', (req, res) => {
    db.get(`SELECT * FROM sensor_data ORDER BY timestamp DESC LIMIT 1`, (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(row || {});
    });
});

// 获取历史数据（指定天数）
app.get('/api/history', (req, res) => {
    const days = req.query.days || 7;
    db.all(`SELECT * FROM sensor_data 
            WHERE datetime(timestamp) >= datetime('now', '-${days} days')
            ORDER BY timestamp DESC`, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// 获取最近24小时数据
app.get('/api/last24h', (req, res) => {
    db.all(`SELECT * FROM sensor_data 
            WHERE datetime(timestamp) >= datetime('now', '-24 hours')
            ORDER BY timestamp ASC`, (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// 获取图片列表
app.get('/api/images', (req, res) => {
    const limit = req.query.limit || 20;
    db.all(`SELECT * FROM images ORDER BY timestamp DESC LIMIT ?`, [limit], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// 获取设备配置
app.get('/api/config', (req, res) => {
    db.get(`SELECT * FROM device_config WHERE id=1`, (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(row || {});
    });
});

// 更新设备配置
app.post('/api/config', (req, res) => {
    const config = req.body;
    db.run(`UPDATE device_config SET 
            plant_age_days = ?,
            soil_target_min = ?,
            soil_target_max = ?,
            ec_growth_min = ?,
            ec_growth_max = ?,
            watering_cooldown = ?,
            fertilizer_cooldown = ?,
            updated_at = CURRENT_TIMESTAMP
            WHERE id = 1`,
        [config.plant_age_days, config.soil_target_min, config.soil_target_max,
         config.ec_growth_min, config.ec_growth_max,
         config.watering_cooldown, config.fertilizer_cooldown],
        function(err) {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ success: true, message: '配置已更新' });
        }
    );
});

// 获取统计数据
app.get('/api/stats', (req, res) => {
    const stats = {};
    db.get(`SELECT COUNT(*) as count, AVG(health) as avg_health, 
            MAX(health) as max_health, MIN(health) as min_health
            FROM sensor_data WHERE date(timestamp) = date('now')`, (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        stats.today = row;

        db.get(`SELECT AVG(temperature) as avg_temp, AVG(humidity) as avg_humidity,
                AVG(ec) as avg_ec FROM sensor_data 
                WHERE datetime(timestamp) >= datetime('now', '-7 days')`, (err, row) => {
            if (err) return res.status(500).json({ error: err.message });
            stats.weekly = row;
            res.json(stats);
        });
    });
});

// 启动服务器
app.listen(PORT, () => {
    console.log(`Plant system server running at http://localhost:${PORT}`);
});